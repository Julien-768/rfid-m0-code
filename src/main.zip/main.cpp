/*
 Name:		Feather_M0.ino
 Created:	2020/11/18
 Author:	jcourtec
*/

/*
* Hardware configuration
****************************************
* Processor	Feather M0 Adalogger board
* RTC x 1 DS3231
* Sensors
*	Infra-Red board
*		x 2	standard device
*	Temperature probe
*		x 1	PT100 wih MAX31865 digitilazer
*	RFID
*		x 1 Tectus TLB-30-SER
* Servomotor x 1 Hitec HS-53 #TODO
*/

//Libraries
#include "Arduino.h"
#include "time.h"
#include "RTClib.h"
#include "SPI.h"
#include "SD.h"
#include "Servo.h"
#include "ArduinoJson.h"
#include "Adafruit_MAX31865.h"
#include "pt100rtd.h" // for feather M0, in this .h replace #include <pgmspace.h> by #include <avr\pgmspace.h>
#include "SAMD21turboPWM.h"

// Adafruit board pin mapping
#define PIN_VBAT		A1                 // analog input for battery voltage measurement
#define PIN_TEMP_CS		6                  // input for RTD sensor
#define PIN_LED_RED		13	               // input/output for SD card
#define PIN_LED_SD		8	               // input/output for SD card
#define PIN_SD_CS		4	               // input/output for SD card
#define PIN_SD_CD		7	               // input/output for SD card
#define PIN_BUZZER_LED 	9                  // output for buzzer or led
#define PIN_PW_SWITCH	A2				   // input for power switch
#define PIN_PW_SERVO  	A4	               // output for power relay of servomotor
#define PIN_PW_3V       5                  // output for power relay of IRs and RTD
#define PIN_PW_RFID     A5                 // output for power relay of RFID
#define PIN_PW_OFF  	A3                 // output for power relay low battery
#define PIN_IR_1		10                 // input for IR sensor 1
#define PIN_IR_2	    A0             	   // input for IR sensor 2
#define PIN_IR_SEND     11                 // output pwm 38kHz for IR sensor
#define PIN_SERVO		12	               // output pwm for signal servo pin

// output for CS temperature with MAX31865
#define RREF            430.0               // resistance reference for RTD
#define C2F(c)          ((9 * c / 5) + 32)  // temperature conversion function, celcius to fahrenheit

// User parameters
struct Config {
	// Hardware options
	bool opt_IR_1 = true;              // use infraed sensor 1
	bool opt_IR_2 = true;              // use infraed sensor 2
	bool opt_temp_prec = false;         // use temperature recording
	bool opt_servo = false;             // use servomotor
	// Modes and key parameters
	int delay_loop = 10;			    // loop delay in ms (time to sleep between checking sensors) RFID timeout is always adding to this delay_loop
	const char* tag_type = "FDX";       // TAG supported "FDX" / "EM4102"
    int rfid_attempts = 10;             // how many times the RFID will try to read TAG after IR event
	int delay_tag_save = 1; 	        // time in seconds to save a tag sitting on the antenna
	int delay_temp = 10;				// period in seconds to record temperature
	bool mode_day_only = false;   	    // mode to switch off the device at night
	int start_time = 5;			        // in day only mode, hour to start the device, value 0 to 23
	int stop_time = 23;			        // in day only mode, hour to stop the device, 1 to 24
	int mode_capture = 1;               // 1 no captures, 2 capture all, 3 capture specific tags, 4 capture non tagged
	int servo_bird_release_time = 10;   // time in seconds for a captured bird release
	const char* tag_1 = "01101728E6";   // tags for mode capture 3
	const char* tag_2 = "01101728E6";   // tags for mode capture 3
	const char* tag_3 = "01101728E6";   // tags for mode capture 3
	const char* tag_4 = "01101728E6";   // tags for mode capture 3
	const char* tag_5 = "01101728E6";   // tags for mode capture 3
};

//Variables declaration
const char* filename_conf = "/config.txt";                    // config file
Config config;                                                // global configuration object
char filename_data[12];                                       // NB Files names are limited to 8 charaters
File logfile;

Adafruit_MAX31865 Temp = Adafruit_MAX31865(PIN_TEMP_CS);      // Temperature MAX31865
pt100rtd PT100 = pt100rtd();                                  // init the Pt100 table lookup module
RTC_DS3231 rtc;                                               // RTC

DateTime time_compil, now, time_last_tag, time_last_door_closed, time_last_temp, time_file, time_last_voltage;
TimeSpan last_tag_diff;
int hours_current;
int now_ms;
bool rtc_error = false;										   // RTC lost power

bool door_already_closed = false;                              //
Servo Servo_control;		                                   // servo object
int servo_pos_opened = 10;                                     // opened position for servo
int  servo_pos_closed = 170;                                   // closed position for servo
bool capture_order = false;                                    //

float measuredvbat = 0;
bool IR_1 = false, IR_1_previous = false;                      // IR_1 tracker variables
bool IR_2 = false, IR_2_previous = false;                      // IR_2 tracker variables
bool IR_state = false, IR_event = false;                       // IR events variables
String data, IR_name;                                          //
TurboPWM pwm;

int RFID_awake = config.rfid_attempts;
String trx, tag;
char cmd_read_tag[6];               						   // RFID reading command
char test[11];

bool acquisition = true;
bool tag_record = false, tag_event = false;                    //
bool stop_event = false, start_event = false;                  //

float Temperature = 0, Temperature_previous = 0; 			  //,ohms;
float Vbatn = 0, Vbatn_1 = 0, Vbatn_2 = 0;
float Vbat = 0, Vbat_previous = 0;
float V_LVD = 3;											  // Low voltage disconnect

// Functions
/*
  We have so many functions, you'll find them at the end of the file
*/
void blink(uint32_t Pin, int delay_ms, int blink_number);
void error(int error_number);
String isoformat(DateTime t, int ms, String separator);
String isoformat_date(DateTime t) ;
float get_voltage(uint32_t ulPin);
void log_data(String data, const char* filename) ;
void log_data_IR(RTC_DS3231 rtc, bool IR_state, String IR_name, const char* filename) ;
void daily_data_file(char* filename, DateTime t) ;
void loadConfiguration(Config& config);
void load_and_save_local_Configuration(struct Config, Config& config);
void printFile(const char* filename) ;
void checkFault(void);
bool compare(const char* TAG_1, const char* TAG_2);
unsigned int hex2int(char input);
String longlong2String(unsigned long long int bigint) ;
String tag_hex_to_NIC(String src) ;
void shutDownButton(void);

// The setup function runs once when you press reset or power the board
void setup() {
	// Start serial connection
	Serial.begin(9600);
	Serial.setTimeout(500);
	Serial1.begin(9600);
	Serial1.setTimeout(500);
	// Configure the IO
	pinMode(PIN_LED_RED, OUTPUT);
	pinMode(PIN_LED_SD, OUTPUT);
	pinMode(PIN_IR_1, INPUT);
	pinMode(PIN_IR_2, INPUT);
	pinMode(PIN_PW_RFID, OUTPUT);
	pinMode(PIN_PW_3V, OUTPUT);
	pinMode(PIN_IR_SEND, OUTPUT);
	pinMode(PIN_BUZZER_LED, OUTPUT);
    pinMode(PIN_PW_OFF, OUTPUT);
	pinMode(PIN_VBAT, INPUT);
	pinMode(PIN_PW_SWITCH, INPUT);
	pinMode(PIN_PW_OFF, OUTPUT);
	pinMode(PIN_PW_SERVO, OUTPUT);
	digitalWrite(PIN_BUZZER_LED, HIGH);
	digitalWrite(PIN_PW_OFF, HIGH);
	digitalWrite(PIN_PW_RFID, HIGH);
	digitalWrite(PIN_PW_SERVO, LOW);
	digitalWrite(PIN_PW_3V, HIGH);
	
	pwm.setClockDivider(16, false);		// Main clock divided by 16 => 3MHz
	pwm.timer(2, 4, 20, true);			// Use timer 2 for pin PIN_IR_SEND, divide clock by 4, resolution 20, single-slope PWM
	pwm.analogWrite(PIN_IR_SEND, 500);  // PWM frequency is now around 36KHz, dutycycle is 500 / 1000 * 100% = 50%

	Serial.print("Waiting for console opening");
	for (size_t r = 0; r < 20; r++) {
		Serial.print(".");
		delay(300); // wait for console opening
	}
	const String stars = "***********************";
	Serial.println(" ");
	Serial.println(stars);
	Serial.println(stars);
	Serial.println(F("A MIBE TEAM PRODUCTION"));
	Serial.println(stars);
	Serial.println(F("Logging IR, RFID and RTD to log file with RTC timestamp"));
	Serial.println(stars);
	// Print the date and time of program launch
	time_compil = DateTime(F(__DATE__), F(__TIME__));
	Serial.print(isoformat(time_compil, (int)0, ";"));
	Serial.println("\t<= Compilation date");
	Serial.println(stars);
	Serial.println(" ");
	Serial.println(F("-------SETUP-------"));

	delay(1000);

	// see if the card is present and can be initialized:
	if (!SD.begin(PIN_SD_CS)) {
		Serial.println("Error\n");
		Serial.println("SD Card init failed");
		error(2);
	}

	// RTC initialisation
	if (!rtc.begin()) {
		Serial.println("Error\n");
		Serial.println("Couldn't find RTC");
		delay(100);
		Serial.flush();
		abort();
	}
	// TODO create / complete a simple function error to serial print error messsages

	now_ms = millis() % 1000;
	now = rtc.now();

	// Log system start-up
	data = isoformat(now, now_ms, ";") + "System; " + "Start;" + "\n";
	if (now.unixtime() < time_compil.unixtime()) {
		rtc_error = true;
		data = data + isoformat(now, now_ms, ";") + "System; RTC has unknow error;" + "\n";
	}
	// rtc time reset at compilation time
	if (rtc.lostPower()) {
		rtc_error = true;
		data = data + isoformat(now, now_ms, ";") + "System; RTC lost power;" + "\n";
	}
	if (rtc_error) {
		rtc.adjust(time_compil);
		now = rtc.now();
		data = data + isoformat(now, now_ms, ";") + "System; RTC set time to compilation date; ";
	}
	else {
		data = data + isoformat(now, now_ms, ";") + "System; RTC is ok;" ;
	}

	// Creating a new file at setup
	time_file = now;
	daily_data_file(filename_data, now);
	log_data(data, filename_data);

	time_last_tag = now;
	time_last_door_closed = now;
	time_last_temp = now;

	// use this line to load configuration from SD config.txt file
	Serial.println(F("Loading SD card configuration..."));
	//loadConfiguration(config);
	// use this line instead to load configuration from struct object defined in the program
	load_and_save_local_Configuration(Config(), config);

	// Dump config file
	printFile(filename_conf);

	// initialization of the temperature sensor
	if (config.opt_temp_prec == true) {
		Serial.println("MAX31865 PT100 Sensor Test using NIST resistance table.");
		Temp.begin(MAX31865_2WIRE);  // set to 2WIRE
	}

	// initialization of IR variables
	if (config.opt_IR_1 == true) {
		IR_1_previous = digitalRead(PIN_IR_1);
	}

	if (config.opt_IR_2 == true) {
		IR_2_previous = digitalRead(PIN_IR_2);
	}
	// Loading RFID settings
	String cmd_read = "@ru\r";
	if (String(config.tag_type) == "FDX") {
		cmd_read = "@rq\r";
	}
	cmd_read.toCharArray(cmd_read_tag, 6);

	// Initialization of the servo motor
	if (config.mode_capture != 1)
	{	// open the door
		Servo_control.attach(PIN_SERVO);
		Servo_control.write(servo_pos_opened);
		Serial.println(F("Init:\tServo door is opened"));
		delay(2000);
		digitalWrite(PIN_PW_SERVO, LOW);
		digitalWrite(PIN_PW_RFID, HIGH);
	}

	//Initialization Battery voltage
	delay(100);
	Vbatn_2 = get_voltage(PIN_VBAT);
	delay(100);
	Vbatn_1 = get_voltage(PIN_VBAT);
	Vbatn = get_voltage(PIN_VBAT);
	delay(100);

	digitalWrite(PIN_BUZZER_LED, LOW);
	Serial.println(" ");
	Serial.println(F("-------LOOP-------"));
	delay(3000);
}

// the loop function runs over and over again until power down or reset
void loop() {
	// !!!!!!!!!!!!!!!!!!!!!!!!!!!
	// TODO Time offset !
	// !!
	// Set an offset when the RTC second change happen else you could get 40.914s , 40.230s, 40.734s, 41.238s as real time
	// !!!!!!!!!!!!!!!!!!!!!!!!!!!

	// refresh time for the loop
	now_ms = millis() %  1000;
	now = rtc.now();

	// creating a new file each day
	if (now.day() != time_file.day()) {
		time_file = now;
		daily_data_file(filename_data, now);
	}

	// check if acquisition should run according to day only mode
	if (config.mode_day_only == true) {
		hours_current = now.hour();
		// not in the range
		if (hours_current < config.start_time or hours_current > config.stop_time) {
			stop_event = true;
		}
		// in the range
		else {
			start_event = true;
		}
	}

	// stop if running
	if (stop_event and acquisition) {
		// TODO Release Bird / Open door if closed
		acquisition = false;
		digitalWrite(PIN_PW_SERVO, LOW);
		digitalWrite(PIN_PW_3V, LOW);
		digitalWrite(PIN_PW_RFID, LOW);
	} 

	// start if sleeping
	if (start_event and (!acquisition)) {
		acquisition = true;
		digitalWrite(PIN_PW_3V, HIGH);
		digitalWrite(PIN_PW_RFID, HIGH);
	}


	// While acquisition is running
	if (acquisition == true) {
		IR_event = false;

		// Event on infrared sensor 1
		if (config.opt_IR_1 == true) {
			// record infrared beam events
			IR_1 = digitalRead(PIN_IR_1);
			if (IR_1 != IR_1_previous) {
				IR_1_previous = IR_1;
				IR_event = true;
				log_data_IR(rtc, IR_1, "IR 1 ; ", filename_data);
				RFID_awake = config.rfid_attempts;
			}
		}

		// Event on infrared sensor 2
		if (config.opt_IR_2 == true) {
			IR_2 = digitalRead(PIN_IR_2);
			if (IR_2 != IR_2_previous) {
				IR_2_previous = IR_2;
				IR_event = true;
				log_data_IR(rtc, IR_2, "IR 2 ; ", filename_data);
				RFID_awake = config.rfid_attempts;
			}
		}

		// read RFID a certain number of attemps base on external events (IR, ..)
		if (RFID_awake > 0) {
			Serial1.write(cmd_read_tag);
			delay(10);
			trx = Serial1.readStringUntil('\r');
			delay(10);
			trx.trim();
			tag_event = false;
			if (trx.indexOf("-") < 0) {//  if '-' not in trx:
				tag_event = true;
				trx.replace("+ ", "");
				trx.replace("ru", "");
				if (trx.length() >= 5) {	// avoid tagless file names
					if (trx == tag) {	// avoid repeated records
						// now_ms = millis() % 1000; TODO ?
						last_tag_diff = rtc.now() - time_last_tag;
						if (last_tag_diff.seconds() > config.delay_tag_save) {
							tag_record = true;
						}
					}
					else {
						tag_record = true;
					}
				}
			}

			if (config.opt_IR_1 or config.opt_IR_2) {
				RFID_awake--;
			}
		}

		// record a pit tag
		if (tag_record == true) {
			digitalWrite(PIN_BUZZER_LED, HIGH);
			time_last_tag = rtc.now();
			now_ms = millis() % 1000;

			if (String(config.tag_type) == "FDX") {
				tag = tag_hex_to_NIC(trx);
			}
          	else {
            	tag = trx;
          	}
			data = isoformat(time_last_tag, now_ms, ";") + tag + "; A0;";
			log_data(data, filename_data);
			tag_record = false;
			digitalWrite(PIN_BUZZER_LED, LOW);
		}

		// Action with the servo - Capture
		if (config.mode_capture != 1) {
			////////// notifying servo is busy
			////////now = rtc.now();
			////////if (servo_busy)
			////////{
			////////	if (!door_already_closed and time_opened.unixtime() + config.servo_bird_release_time > now.unixtime())
			////////	{
			////////		Serial.println("Servomotor is busy, closing blocked");
			////////		servo_busy = false;
			////////	}
			////////}

			if (config.mode_capture == 2 and IR_event == true) {
				capture_order = true;
			}

			if (config.mode_capture == 4 and tag_event == true) {
				capture_order = true;
			}

			// look for special tag
			if (config.mode_capture == 3 and tag_record == true) {
				trx.toCharArray(test, 11);
				capture_order = compare(test, config.tag_1) or compare(test, config.tag_2) or compare(test, config.tag_3) or compare(test, config.tag_4) or compare(test, config.tag_5);
			}

			// capture
			if (capture_order == true and door_already_closed == false)
			{
				digitalWrite(PIN_PW_SERVO, HIGH);
				Servo_control.write(servo_pos_closed);
				time_last_door_closed = rtc.now();
				Serial.println("Door closed");
				capture_order = false;
				door_already_closed = true;
				delay(2000);
				digitalWrite(PIN_PW_SERVO, LOW);
			}
		}

		// Temperature
		if (config.opt_temp_prec == true and time_last_temp.unixtime() + config.delay_temp <= now.unixtime()) {
			uint16_t rtd, ohmsx100;
			uint32_t dummy;
			rtd = Temp.readRTD();

			// Use uint16_t (ohms * 100) since it matches data type in lookup table.
			dummy = ((uint32_t)(rtd << 1)) * 100 * ((uint32_t)floor(RREF));
			dummy >>= 16;
			ohmsx100 = (uint16_t)(dummy & 0xFFFF);

			// or use exact ohms floating point value.
			//ohms = (float)(ohmsx100 / 100) + ((float)(ohmsx100 % 100) / 100.0);
			//Serial.print("rtd: 0x"); Serial.print(rtd, HEX);
			//Serial.print(", ohms: "); Serial.println(ohms, 2);

			// LookUp Table method
			Temperature = PT100.celsius(ohmsx100);
			checkFault();
			time_last_temp = rtc.now();
			now_ms = millis() % 1000;
			if (abs(Temperature_previous - Temperature) > 0.02) {
				Temperature_previous = Temperature;
				now_ms = millis() % 1000;
				data = isoformat(time_last_temp, now_ms, ";") + "Temperature; " + Temperature + "C° ;";
				log_data(data, filename_data);
			}

		}

	}

	// Action with the servo - Release
	if (config.mode_capture != 1) {
		// Release bird
		if ((time_last_door_closed.unixtime() + config.servo_bird_release_time < now.unixtime()) and door_already_closed) {
			digitalWrite(PIN_PW_SERVO, HIGH);
			Servo_control.write(servo_pos_opened);
			door_already_closed = false;
			Serial.println("Door opened");
			delay(2000);
			digitalWrite(PIN_PW_SERVO, LOW);
		}
	}


	// check battery voltage every X s
	if (time_last_voltage.unixtime() + 2 <= now.unixtime()) {
		
		time_last_voltage = now;

		Vbatn_2 = Vbatn_1;
		Vbatn_1 = Vbatn;
		Vbatn = get_voltage(PIN_VBAT);

		Vbat = (Vbatn_2 + Vbatn_1 + Vbatn)/3;

		// voltage measurement
		if (abs(Vbat_previous - Vbat) > 0.1) {
			Vbat_previous = Vbat;
			now_ms = millis() % 1000;
			data = isoformat(rtc.now(), now_ms, ";") + "Vbat; " + String(Vbat) + "V ;";
			log_data(data, filename_data);
		}
		// sleep mode
		if ((Vbat <= V_LVD + 0.1) and acquisition == true) {
			data = isoformat(rtc.now(), now_ms, ";") + "Vbat; " + String(Vbat) + "V ;";
			log_data(data, filename_data);
			data = isoformat(rtc.now(), now_ms, ";") + "System; " + "Sleep mode;";
			log_data(data, filename_data);
			stop_event = true;
			start_event = false;
		}
		// wake up mode
		if ((Vbat >= V_LVD + 0.2) and acquisition == false) {
			data = isoformat(rtc.now(), now_ms, ";") + "Vbat; " + String(Vbat) + "V ;";
			log_data(data, filename_data);
			data = isoformat(rtc.now(), now_ms, ";") + "System; " + "Wake up mode;";
			log_data(data, filename_data);
			stop_event = false;
			start_event = true;
		}
		// power off
		if (Vbat <= V_LVD) {
			data = isoformat(rtc.now(), now_ms, ";") + "Vbat; " + String(Vbat) + "V ;";
			log_data(data, filename_data);
			data = isoformat(rtc.now(), now_ms, ";") + "System; " + "Battery Low;";
			log_data(data, filename_data);
			blink(PIN_BUZZER_LED, 100, 6);
			digitalWrite(PIN_PW_OFF, LOW);
		}
	}

	// check general switch
	shutDownButton();
	delay(config.delay_loop);
}

// blink function
void blink(uint32_t Pin, int delay_ms, int blink_number) {
	for (uint8_t i = 0; i < blink_number; i++) {
		digitalWrite(Pin, HIGH);
		delay(delay_ms);
		digitalWrite(Pin, LOW);
		delay(delay_ms);
	}
}

// blink out an error code
void error(int error_number) {
	while (1) {
		uint8_t i;
		blink(LED_BUILTIN, 100, error_number);
		for (i = error_number; i < 10; i++) {
			delay(200);
		}
	}
}

// isoformat a date and timestamp without millisecond
String isoformat(DateTime t, int ms, String separator) {
	// '2019-05-10T09:08:53.155'
	// for millisecond attachInterrupt pin on the RTC and use interrupt routine
	return String(t.year()) + "-" + String(t.month()) + "-" + String(t.day()) + separator + String(t.hour()) + ":" + String(t.minute()) + ":" + String(t.second()) + "." + String(ms) + ";";
}

// isoformat a date without millisecond
String isoformat_date(DateTime t) {
	if (t.month() < 10 and t.day() < 10) {
		return String(t.year() - 2000) + "_0" + String(t.month()) + "_0" + String(t.day());
	}
	else if (t.month() >= 10 and t.day() >= 10) {
		return String(t.year() - 2000) + "_" + String(t.month()) + "_" + String(t.day());
	}
	else if (t.month() >= 10 and t.day() < 10) {
		return String(t.year() - 2000) + "_" + String(t.month()) + "_0" + String(t.day());
	}
	else {
		return String(t.year() - 2000) + "_0" + String(t.month()) + "_" + String(t.day());
	}
}

// get battery voltage
float get_voltage(uint32_t ulPin) {
	float measuredvbat = analogRead(ulPin);
	measuredvbat *= 2;    // we divided by 2, so multiply back
	measuredvbat *= 3.3;  // Multiply by 3.3V, our reference voltage
	measuredvbat /= 1024; // convert to voltage
	return measuredvbat;
}

// log data to file with battery voltage
void log_data(String data, const char* filename) {
	digitalWrite(PIN_LED_SD, HIGH);
	File log = SD.open(filename, FILE_WRITE);
	if (!log) {
		Serial.print("Couldnt create ");
		Serial.println(filename);
		Serial.println("error 3");
		error(3);
	}
	log.println(data);
	log.close();
	Serial.print("logged data:\n");
	Serial.println(data);
	digitalWrite(PIN_LED_SD, LOW);
}

// log data to file with battery voltage
void log_data_IR(RTC_DS3231 rtc, bool IR_state, String IR_name, const char* filename) {
	now_ms = millis() % 1000;
	data = isoformat(rtc.now(), now_ms, ";") + IR_name;
	if (IR_state == 1) {
		data += "broken beam ; ";
	}
	else {
		data += "beam restored ; ";
	}
	log_data(data, filename_data);
}

// create a file each day
void daily_data_file(char* filename, DateTime t) {
	// NB Files names are limited to 8 charaters
	strcpy(filename, "01_01_00.TXT"); // beware that filenames cannot exceed 8 or 9 characters
	char date[11];
	// get isoformat date for filename
	isoformat_date(t).toCharArray(date, 11);
	for (int i = 0; i < 8;) {
		filename[i + 0] = date[i];
		i++;
	}
	// check if the file exists
	if (SD.exists(filename)) {
		Serial.print("The data file already exist\t");
	}
	else {
		Serial.print("Creating the data file\t");
	}
			Serial.println(filename);
	
	logfile = SD.open(filename, FILE_WRITE);
	if (!logfile) {
		Serial.print("Couldnt create\t");
		Serial.println(filename);
		Serial.println("error 3");
		error(3);
	}
	else {
		Serial.print("The data file was found or created with success\t");
		Serial.println(filename);
	}
	logfile.close();
}

// Loads the configuration from a file
void loadConfiguration(Config& config) {
	// from https://arduinojson.org/
	File file_c = SD.open(filename_conf); // open file for reading
	StaticJsonDocument<512> doc;
	DeserializationError error = deserializeJson(doc, file_c);
	if (error) {
		Serial.println(F("Failed to read file, using default configuration"));
		// maybe your StaticJsonDocument<SIZE> doc; is to small
	}
	// TODO better
	// Copy values from the JsonDocument to the Config
	config.opt_IR_1 = doc["opt_IR_1"];
	config.opt_IR_2 = doc["opt_IR_2"];
	config.opt_temp_prec = doc["opt_temp_prec"];
	config.opt_servo = doc["opt_servo"];
	config.mode_day_only = doc["mode_day_only"];
	config.mode_capture = doc["mode_capture"];
	config.start_time = doc["start_time"];
	config.stop_time = doc["stop_time"];
	config.delay_loop = doc["delay_loop"];
	config.tag_type = doc["tag_type"];
	config.rfid_attempts = doc["rfid_attempts"];
  	config.delay_tag_save = doc["delay_tag_save"];
	config.delay_temp = doc["delay_temp"];
	config.servo_bird_release_time = doc["servo_bird_release_time"];
	config.tag_1 = doc["tag_1"];
	config.tag_2 = doc["tag_2"];
	config.tag_3 = doc["tag_3"];
	config.tag_4 = doc["tag_4"];
	config.tag_5 = doc["tag_5"];
	file_c.close();
}

//loading local configuration to config object
void load_and_save_local_Configuration(struct Config, Config& config) {
	config.opt_IR_1 = Config().opt_IR_1;
	config.opt_IR_2 = Config().opt_IR_2;
	config.opt_temp_prec = Config().opt_temp_prec;
	config.opt_servo = Config().opt_servo;
	config.mode_day_only = Config().mode_day_only;
	config.mode_capture = Config().mode_capture;
	config.start_time = Config().start_time;
	config.stop_time = Config().stop_time;
	config.delay_loop = Config().delay_loop;
	config.tag_type = Config().tag_type;
	config.rfid_attempts = Config().rfid_attempts;
	config.delay_tag_save = Config().delay_tag_save;
	config.delay_temp = Config().delay_temp;
	config.servo_bird_release_time = Config().servo_bird_release_time;
	config.tag_1 = Config().tag_1;
	config.tag_2 = Config().tag_2;
	config.tag_3 = Config().tag_3;
	config.tag_4 = Config().tag_4;
	config.tag_5 = Config().tag_5;

	//removing the old file and creating a new one
	SD.remove(filename_conf);
	delay(5);
	File file = SD.open(filename_conf, FILE_WRITE);
	if (!file) {
		Serial.println(F("Failed to create file"));
	}

	StaticJsonDocument<512> doc;

	// Set the values in the document
	doc["opt_IR_1"] = config.opt_IR_1;
	doc["opt_IR_2"] = config.opt_IR_2;
	doc["opt_temp_prec"] = config.opt_temp_prec;
	doc["opt_servo"] = config.opt_servo;
	doc["mode_day_only"] = config.mode_day_only;
	doc["mode_capture"] = config.mode_capture;
	doc["start_time"] = config.start_time;
	doc["stop_time"] = config.stop_time;
	doc["delay_loop"] = config.delay_loop;
	doc["tag_type"] = config.tag_type;
	doc["rfid_attempts"] = config.rfid_attempts;
	doc["delay_tag_save"] = config.delay_tag_save;
	doc["delay_temp"] = config.delay_temp;
	doc["servo_bird_release_time"] = config.servo_bird_release_time;
	doc["tag_1"] = config.tag_1;
	doc["tag_2"] = config.tag_2;
	doc["tag_3"] = config.tag_3;
	doc["tag_4"] = config.tag_4;
	doc["tag_5"] = config.tag_5;

	if (serializeJson(doc, file) == 0) {
		Serial.println(F("Failed to write to config file"));
	}
	file.close();
}

// Prints the content of a file to the Serial
void printFile(const char* filename) {
	// from https://arduinojson.org/
	File file = SD.open(filename);
	char letter;
	if (!file) {
		Serial.println(F("Failed to read file"));
		return;
	}
	else {
		Serial.print(F("Print file "));
		Serial.println(filename);
		Serial.print('\t');
	}
	// Extract each characters by one by one
	while (file.available()) {
		letter = (char)file.read();
		if (letter == ',')
		{
			Serial.println(letter);
			Serial.print('\t');
		}
		else
		{
			Serial.print(letter);
		}
	}
	Serial.println();
	file.close();
}

// Check and print any faults
void checkFault(void) {
	uint8_t fault = Temp.readFault();
	if (fault)
	{
		Serial.print("Fault 0x"); Serial.println(fault, HEX);
		if (fault & MAX31865_FAULT_HIGHTHRESH) {
			Serial.println("RTD High Threshold");
		}
		if (fault & MAX31865_FAULT_LOWTHRESH) {
			Serial.println("RTD Low Threshold");
		}
		if (fault & MAX31865_FAULT_REFINLOW) {
			Serial.println("REFIN- > 0.85 x Bias");
		}
		if (fault & MAX31865_FAULT_REFINHIGH) {
			Serial.println("REFIN- < 0.85 x Bias - FORCE- open");
		}
		if (fault & MAX31865_FAULT_RTDINLOW) {
			Serial.println("RTDIN- < 0.85 x Bias - FORCE- open");
		}
		if (fault & MAX31865_FAULT_OVUV) {
			Serial.println("Under/Over voltage");
		}
		Temp.clearFault();
	}
}

bool compare(const char* TAG_1, const char* TAG_2) {
	// compare only last characters of the TAG
	for (int i = 0; i < 10; i++) {
		if (!(TAG_1[i] == TAG_2[i])) {
			return false;
		}
	}
	return true;
}

// Convert char hexadecimal to int number
unsigned int hex2int(char input) {
  if (input >= '0' && input <= '9') {
    return input - '0';
  }
  else {
    if (input >= 'A' && input <= 'F') {
      return input - 'A' + 10;
    }
    else {
      if (input >= 'a' && input <= 'f') {
        return input - 'a' + 10;
      }
      else {
        return '0';
      }
    }
  }
}

// Conversion long long int number to a String
String longlong2String(unsigned long long int bigint) {
  String s = "";
  int digit;

  //for eatch decimal digit of the long long bigint, extract it and convert it in string
  while (bigint > 0) {
    digit = (bigint % 10);		// get the last decimal digit of bigint   
    s = String(digit) + s;		// convert the digit in string and add it to output
    bigint = bigint / 10;		// truncate the last decimal digit        

  }

  return s;
}

// Conversion Tag FDX from Hexadecimal to National Identification Code(NIC)
String tag_hex_to_NIC(String src) {
  /*
  input : String of tag hexadecimal number. exemple: [ scr = "80003EB533A9F1FA" ]
  output : String of tag converted with countryCode - CodeNIC [ "250-228500042234" ]
  */
  char hex[12]; 
  unsigned int a, z = 0;
  unsigned int codePays = 0;        //country code 3 decimals / 10bits [ 250 ]
  unsigned long long int codeNIC = 0;   // National Identificatin Code (NIC) on 12decimals / 38bits [ 228500042234 ]
  if (src.length() == 16)         //FDX tag length is 16 hex [ 0x80003EB533A9F1FA ]
  {
    /*keep only the last 12 hexa digit that contain the Codes [0x3EB533A9F1FA] and convert it to char array*/
    src.toCharArray(hex, 13, 4);      

    //Conversion of the 3 first hex digit to get the codePays
    for (int i = 0; i < 3; i++) {
                      // get hex digit [ for i = 2; hexL[i] = 0xB ]
      a = hex2int(hex[i]);      //conversion to int [ a = 11 = 0b1011 ]
      z = (z << 4) | a;       // add the 4 bits of the hexa digit at the end of z 
                      // [ z = 62 = 0b 0011 1110  -> becomes -> z = 1003 = 0b 0011 1110 1011]

    }
    codePays = z >> 2;          // supress last 2 bits of z to get code Pays [ codePays = 0b 0011 1110 10 = 250]

    codeNIC = (3 & z);          //get the last 2 bits to begin codeNIC [ codeNIC = 0b 11 ]

    //Conversion of the rest of hex digit to get the codeNIC
    for (size_t i = 3; i < strlen(hex); i++) {
		                  // get hex digit [ for i = 3; hexL[i] = 0x5 ]
      a = hex2int(hex[i]);      //conversion to int [ a = 5 = 0b0101 ]
      codeNIC = (codeNIC << 4) | a; // add the 4 bits of the hexa digit at the end of codeNIC
                      // [ codeNIC = 0b 11  -> becomes -> codeNIC = 0b 11 0101]
    }

    return (String(codePays) + "-" + longlong2String(codeNIC));
  }
  else return "err: tag hexa de mauvaise taille";

}

// Power interrupt
void shutDownButton(void) {
	bool stateButton = digitalRead(PIN_PW_SWITCH);
	int loops = 0;
	while (stateButton == true) {
		loops = loops + 1;
		digitalWrite(PIN_BUZZER_LED, HIGH);
		delay(100);
		digitalWrite(PIN_BUZZER_LED, LOW);
		delay(100);
		stateButton = digitalRead(PIN_PW_SWITCH);
		if (loops == 6) {
			digitalWrite(PIN_BUZZER_LED, HIGH);
			data = isoformat(rtc.now(), now_ms, ";") + "System; " + "Shut Down Button;";
			log_data(data, filename_data);
			delay(1000);
			digitalWrite(PIN_PW_OFF, LOW);
			while (1) {
				delay(10000);
			}
		}
	}
}